import os
from pathlib import Path
import subprocess

workspace = Path(__file__).resolve().parent
repo = workspace / "comparison"
logs = workspace / "campaign"
at = "/mnt/c/Users/Laszlos/source/repos/Solo/qb5b09-plain-q1"
file = "tests/BoltSharp.Tests/Transport/PlaintextTerminalCloseTests.cs"
project = "tests/BoltSharp.Tests/BoltSharp.Tests.csproj"
dll = "tests/BoltSharp.Tests/bin/Debug/net8.0/BoltSharp.Tests.dll"
server = "src/BoltSharp/Transport/BoltTcpServer.cs"
revisions = {
    "original": "fac10f6c5ece37dbc3f38c9c831c668d49a3d290",
    "linger": "dac52d55ade0a9ae703b801c8a4066e8aef2bd58",
    "candidate": "20fbc461c0257620db28fb78a463218b242455bc",
}

def run(args, name):
    with (logs / f"{name}.log").open("wb") as output:
        return subprocess.run(args, cwd=repo, stdout=output, stderr=subprocess.STDOUT).returncode

def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo)

def campaign(platform, label, tests):
    name = f"{platform}-q1-{label}"
    scope = "|".join(f"FullyQualifiedName~PlaintextTerminalCloseTests.{test}" for test in tests)
    if platform == "win":
        args = ["dotnet", "test", project, "--no-build", "--no-restore", "-nodeReuse:false", "--filter",
                scope, "--logger", f"trx;LogFileName={name}.trx", "--results-directory", str(logs)]
    else:
        args = ["wsl.exe", "-d", "Ubuntu", "--", "bash", f"{at}/wsl-comparison.sh", label]
    return run(args, name)

assert git("status", "--porcelain") == b""
template = git("show", f"{revisions['candidate']}:{file}").decode()
probes = (workspace / "reviewer-probes.cs.txt").read_text(encoding="utf-8")
template = template.replace("    private static CancellationTokenSource Limit()", probes + "    private static CancellationTokenSource Limit()")
template = template.replace("        internal TcpClient Socket { get; } = socket;", "        internal TcpClient Socket { get; } = socket;\n        internal Stream Raw => stream;")
readback = '''
    private static readonly System.Diagnostics.DiagnosticListener Q1AcceptedLinger =
        new("BoltSharp.Q1.AcceptedLinger");
'''
with (logs / "q1-comparison-status.log").open("w", encoding="utf-8") as ledger:
    for label, rev in revisions.items():
        git("checkout", "--detach", rev)
        server_path = repo / server
        test_path = repo / file
        original = server_path.read_bytes()
        original_test = test_path.read_bytes() if test_path.exists() else None
        try:
            source = server_path.read_text(encoding="utf-8")
            source = source.replace("    private readonly BoltTransportDiagnostics", readback + "\n    private readonly BoltTransportDiagnostics", 1)
            source = source.replace("            client.NoDelay = true;", '            Q1AcceptedLinger.Write("accepted", client.LingerState);\n            client.NoDelay = true;', 1)
            server_path.write_text(source, encoding="utf-8", newline="\n")
            test_path.write_text(template, encoding="utf-8", newline="\n")
            (logs / f"q1-{label}-readback.patch").write_bytes(git("diff", "--", server))
            if label == "original":
                assert run(["dotnet", "restore", project, "--ignore-failed-sources"], "q1-restore") == 0
            if label in ("original", "candidate"):
                assert run(["dotnet", "build", "BoltSharp.slnx", "--no-restore", "-nodeReuse:false",
                            "-t:Rebuild"], f"q1-{label}-build") == 0
            else:
                assert run(["dotnet", "build", project, "--no-restore", "-nodeReuse:false"],
                           f"q1-{label}-build") == 0
            for platform in ("win", "wsl"):
                tests = ["Q1PortableStartupAndAcceptedReadback"]
                if platform == "win" or label != "original":
                    tests.append("Q1RawQueuedTail")
                print(platform, label, campaign(platform, label, tests), file=ledger, flush=True)
                if label == "candidate":
                    print(platform, "bounds", campaign(platform, "bounds",
                          ["Q1ExactDrainBoundary", "Q1CancelAfterAdmissionAndRecover",
                           "Q1ShutdownExceptionReturnsPermit"]), file=ledger, flush=True)
                    print(platform, "write-classification", campaign(platform, "write-classification",
                          ["Q1WriteTimeoutMustEndAtWriteAndFlush"]), file=ledger, flush=True)
        finally:
            server_path.write_bytes(original)
            if original_test is None:
                test_path.unlink(missing_ok=True)
            else:
                test_path.write_bytes(original_test)
            assert git("status", "--porcelain") == b""
            print(label, rev, "restored clean", file=ledger, flush=True)
