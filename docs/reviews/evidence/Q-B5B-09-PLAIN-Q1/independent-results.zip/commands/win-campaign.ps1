param([string]$Source = (Join-Path $PSScriptRoot 'source'),
      [string]$Results = (Join-Path $PSScriptRoot 'campaign'))

$log = (New-Item -ItemType Directory -Force $Results).FullName
Push-Location $Source
try {
    $core = 'tests/BoltSharp.Tests/BoltSharp.Tests.csproj'
    $driver = 'tests/BoltSharp.DriverInteropTests/BoltSharp.DriverInteropTests.csproj'
    dotnet restore BoltSharp.slnx --ignore-failed-sources *> "$log\win-restore-solution.log"
    if ($LASTEXITCODE) { exit $LASTEXITCODE }
    dotnet restore $driver --ignore-failed-sources *> "$log\win-restore-driver.log"
    if ($LASTEXITCODE) { exit $LASTEXITCODE }
    $projects = @('src/BoltSharp/BoltSharp.csproj', 'BoltSharp.slnx', $driver)
    for ($i = 0; $i -lt $projects.Count; $i++) {
        dotnet build $projects[$i] --no-restore -nodeReuse:false *> "$log\win-build-$i.log"
        if ($LASTEXITCODE) { exit $LASTEXITCODE }
    }
    dotnet test $core --no-build --no-restore -nodeReuse:false --logger 'trx;LogFileName=win-core.trx' --results-directory $log *> "$log\win-core.log"
    dotnet test $driver --no-build --no-restore -nodeReuse:false --logger 'trx;LogFileName=win-driver.trx' --results-directory $log *> "$log\win-driver.log"
    $filter = 'FullyQualifiedName~PlaintextTerminalClose|FullyQualifiedName~TlsIntegrationTests|FullyQualifiedName~TcpListenerTests|FullyQualifiedName~MultiClient'
    foreach ($i in 1..3) {
        dotnet test $core --no-build --no-restore -nodeReuse:false --filter $filter --logger "trx;LogFileName=win-focused-$i.trx" --results-directory $log *> "$log\win-focused-$i.log"
    }
    $scope = git diff --name-only fac10f6 20fbc46
    $driverScope = $scope | Where-Object { $_ -like 'tests/BoltSharp.DriverInteropTests/*' }
    $coreScope = $scope | Where-Object { $_ -notin $driverScope }
    dotnet format BoltSharp.slnx --verify-no-changes --no-restore --include $coreScope *> "$log\win-format-solution.log"
    $solutionFormat = $LASTEXITCODE
    dotnet format $driver --verify-no-changes --no-restore --include $driverScope *> "$log\win-format-driver.log"
    "solution format exit=$solutionFormat; driver format exit=$LASTEXITCODE" | Set-Content "$log\win-format-status.log"
    dotnet --info > "$log\win-dotnet-info.log"
    dotnet --list-runtimes >> "$log\win-dotnet-info.log"
}
finally {
    Pop-Location
}
