set -u
cd /mnt/c/Users/Laszlos/source/repos/Solo/qb5b09-plain-q1/source || exit
logs="$PWD/../campaign"
export DOTNET_ROLL_FORWARD=Major
dotnet --info > "$logs/wsl-dotnet-info.log"
env | sort | sed -n '/^DOTNET_ROLL_FORWARD=/p' >> "$logs/wsl-dotnet-info.log"
core=tests/BoltSharp.Tests/bin/Debug/net8.0/BoltSharp.Tests.dll
driver=tests/BoltSharp.DriverInteropTests/bin/Debug/net8.0/BoltSharp.DriverInteropTests.dll
dotnet vstest "$core" '--Logger:trx;LogFileName=wsl-core.trx' "--ResultsDirectory:$logs" > "$logs/wsl-core.log" 2>&1
dotnet vstest "$driver" '--Logger:trx;LogFileName=wsl-driver.trx' "--ResultsDirectory:$logs" > "$logs/wsl-driver.log" 2>&1
scope='FullyQualifiedName~PlaintextTerminalClose|FullyQualifiedName~TlsIntegrationTests|FullyQualifiedName~TcpListenerTests|FullyQualifiedName~MultiClient'
for i in 1 2 3; do
  dotnet vstest "$core" "--TestCaseFilter:$scope" "--Logger:trx;LogFileName=wsl-focused-$i.trx" "--ResultsDirectory:$logs" > "$logs/wsl-focused-$i.log" 2>&1
done