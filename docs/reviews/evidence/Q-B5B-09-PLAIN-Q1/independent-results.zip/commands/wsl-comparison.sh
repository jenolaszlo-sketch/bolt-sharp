set -u
base=/mnt/c/Users/Laszlos/source/repos/Solo/qb5b09-plain-q1
cd "$base/comparison" || exit
label=$1
export DOTNET_ROLL_FORWARD=Major
export Q1_ORIGINAL=0
case "$label" in
  original)
    Q1_ORIGINAL=1
    scope="Q1PortableStartupAndAcceptedReadback"
    ;;
  linger|candidate)
    scope="Q1PortableStartupAndAcceptedReadback|FullyQualifiedName~Q1RawQueuedTail"
    ;;
  bounds)
    scope="Q1ExactDrainBoundary|FullyQualifiedName~Q1CancelAfterAdmissionAndRecover|FullyQualifiedName~Q1ShutdownExceptionReturnsPermit"
    ;;
  write-classification)
    scope="Q1WriteTimeoutMustEndAtWriteAndFlush"
    ;;
  *)
    exit 64
esac
dotnet vstest tests/BoltSharp.Tests/bin/Debug/net8.0/BoltSharp.Tests.dll \
  "--TestCaseFilter:FullyQualifiedName~$scope" \
  "--Logger:trx;LogFileName=wsl-q1-$label.trx" "--ResultsDirectory:$base/campaign"
