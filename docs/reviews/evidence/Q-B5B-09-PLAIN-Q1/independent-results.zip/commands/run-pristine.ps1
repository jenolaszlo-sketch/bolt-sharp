$start = (Get-Location).Path
$log = (Get-Item ..\campaign).FullName
$project = 'tests/BoltSharp.Tests/BoltSharp.Tests.csproj'
$orig = git rev-parse HEAD
try {
    foreach ($label in @('original', 'linger')) {
        $revision = if ($label -eq 'original') { 'fac10f6' } else { 'dac52d5' }
        $filter = if ($label -eq 'original') { 'FullyQualifiedName~Start_BindsEphemeralPort_AndReportsEndPoint|FullyQualifiedName~TlsConversation_CompletesScalarQuery' } else { 'FullyQualifiedName~Startup_UsesDisabledLinger' }
        git checkout --detach $revision
        if ($LASTEXITCODE) { exit $LASTEXITCODE }
        if (git status --porcelain) { throw "Comparison checkout must be clean" }
        dotnet build $project --no-restore -nodeReuse:false *> "$log\q1-$label-pristine-build.log"
        if ($LASTEXITCODE) { exit $LASTEXITCODE }
        dotnet test $project --no-build --no-restore -nodeReuse:false --filter $filter --logger "trx;LogFileName=win-q1-$label-pristine.trx" --results-directory $log *> "$log\win-q1-$label-pristine.log"
        wsl.exe -d Ubuntu -- bash /mnt/c/Users/Laszlos/source/repos/Solo/qb5b09-plain-q1/wsl-pristine.sh $label *> "$log\wsl-q1-$label-pristine.log"
    }
}
finally {
    git -C $start checkout --detach $orig
    if (git -C $start status --porcelain) { throw "Comparison checkout did not restore cleanly" }
}
