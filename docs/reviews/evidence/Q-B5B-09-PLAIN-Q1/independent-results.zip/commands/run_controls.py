import os
from pathlib import Path
import subprocess
import sys

workspace = Path(__file__).resolve().parent
repo = workspace / "controls"
logs = workspace / "campaign"
project = "tests/BoltSharp.Tests/BoltSharp.Tests.csproj"
prefix = "src/BoltSharp/"
close = prefix + "Transport/BoltPlaintextTerminalClose.cs"
connection = prefix + "Transport/BoltTcpConnection.cs"
server = prefix + "Transport/BoltTcpServer.cs"
session = prefix + "Sessions/BoltConnectionSession.cs"
controls = {
    "01": ("ExactFailureAndNoTrailingExecution", [
        (session, "            return authenticated ? refusal.MarkPlaintextCloseEligible() : refusal;",
         "            if (authenticated)\n                _state = BoltConnectionState.Ready;\n            return authenticated ? refusal.MarkPlaintextCloseEligible() : refusal;"),
        (connection, "                        diagnostics.Report(BoltTransportEventKind.MessageProcessed, connectionId,",
         "                        if (await reader.ReadMessageAsync(cancellation).ConfigureAwait(false) is { } queued)\n                            _ = session.ReceiveBytes(queued);\n                        diagnostics.Report(BoltTransportEventKind.MessageProcessed, connectionId,"),
    ]),
    "02": ("ListenerStopJoinsActualHandleAndReturnsPermit", [
        (connection, "        using var clientOwnership = client;", "        var clientOwnership = client;"),
        (close, "                Client.Dispose();", "                GC.KeepAlive(Client);"),
    ]),
    "03": ("ListenerStopJoinsActualHandleAndReturnsPermit", [
        (close, 'using var onListener = listener.UnsafeRegister(_ => owner.Interrupt("listener-shutdown"), null);',
         '// Fault injection: leave the listener unregistered.'),
    ]),
    "04": ("OneDeadlineCoversWriteAndDrain", [
        (close, "            ArmPhaseTimer(drain, DrainBudget, started, owner);",
         "            total.CancelAfter(TotalBudget);\n            ArmPhaseTimer(drain, DrainBudget, Stopwatch.GetTimestamp(), owner);"),
    ]),
    "05": ("ExactFailureAndNoTrailingExecution", [
        (close, "private const int DrainByteLimit = 8 * 1024;", "private const int DrainByteLimit = 12 * 1024;"),
    ]),
    "06": ("DrainAdmissionAndRecovery", [
        (close, "new SemaphoreSlim(Math.Min(1, maxConnections - 1), 1)",
         "new SemaphoreSlim(Math.Min(2, maxConnections - 1), 2)"),
    ]),
    "07": ("TlsRefusalNeverEntersPlaintextHelper", [
        (server, "options.Tls is null ? new BoltPlaintextTerminalClose(options.MaxConnections) : null",
         "new BoltPlaintextTerminalClose(options.Tls is null ? options.MaxConnections : 1)"),
        (connection, "options.Tls is null ? plaintextClose : null,", "plaintextClose,"),
        (connection, "plaintextClose.RunAsync(client, (NetworkStream)stream, connectionId",
         "plaintextClose.RunAsync(client, client.GetStream(), connectionId"),
    ]),
}


def run(args, log):
    with (logs / log).open("wb") as file:
        return subprocess.run(args, cwd=repo, stdout=file, stderr=subprocess.STDOUT).returncode


def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo)


def test(name, names):
    filter_expr = "|".join(f"FullyQualifiedName~PlaintextTerminalCloseTests.{name}" for name in names)
    args = ["dotnet", "test", project, "--no-restore", "-nodeReuse:false", "--filter", filter_expr,
            "--logger", f"trx;LogFileName={name}.trx", "--results-directory", str(logs)]
    return run(args, f"{name}.log")


def verify_clean():
    assert git("rev-parse", "HEAD").decode().strip() == "20fbc461c0257620db28fb78a463218b242455bc"
    assert git("status", "--porcelain") == b""


verify_clean()
assert run(["dotnet", "restore", project, "--ignore-failed-sources"], "nc-restore.log") == 0
with (logs / "nc-exit-and-restoration.log").open("w", encoding="utf-8") as results:
    baseline = test("nc-00", sorted({case[0] for case in controls.values()}))
    print("NC-00", baseline, "original", file=results, flush=True)
    assert baseline == 0
    for number, (filter_name, edits) in controls.items():
        name = f"nc-{number}"
        originals = {path: (repo / path).read_bytes() for path, _, _ in edits}
        try:
            for path, before, after in edits:
                target = repo / path
                data = target.read_bytes()
                eol = "\r\n" if b"\r\n" in data else "\n"
                old = before.replace("\n", eol).encode()
                new = after.replace("\n", eol).encode()
                assert data.count(old) == 1, (name, path, before)
                target.write_bytes(data.replace(old, new))
            (logs / f"{name}.patch").write_bytes(git("diff", "--binary"))
            print(name.upper(), test(name, [filter_name]), file=results, flush=True)
        finally:
            for path, data in originals.items():
                (repo / path).write_bytes(data)
            verify_clean()
            print(name.upper(), "verified byte restoration and a clean original checkout", file=results, flush=True)
    print("NC-00-RESTORED", test("nc-00-restored", sorted({case[0] for case in controls.values()})),
          file=results, flush=True)
    verify_clean()
