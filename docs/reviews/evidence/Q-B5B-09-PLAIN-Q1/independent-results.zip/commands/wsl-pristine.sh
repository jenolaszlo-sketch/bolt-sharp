set -u
base=/mnt/c/Users/Laszlos/source/repos/Solo/qb5b09-plain-q1
cd "$base/comparison" || exit
export DOTNET_ROLL_FORWARD=Major
label=$1
if [ "$label" = "original" ]; then
  scope="Start_BindsEphemeralPort_AndReportsEndPoint|FullyQualifiedName~TlsConversation_CompletesScalarQuery"
else
  scope="Startup_UsesDisabledLinger"
fi
dotnet vstest tests/BoltSharp.Tests/bin/Debug/net8.0/BoltSharp.Tests.dll \
  "--TestCaseFilter:FullyQualifiedName~$scope" \
  "--Logger:trx;LogFileName=wsl-q1-$label-pristine.trx" "--ResultsDirectory:$base/campaign"
