#!/usr/bin/env bash
base=/mnt/c/Users/Laszlos/source/repos/Solo/qb5b09-plain-r1
cd "$base/baseline" || exit
export DOTNET_ROLL_FORWARD=Major
dotnet vstest tests/BoltSharp.Tests/bin/Debug/net8.0/BoltSharp.Tests.dll '--TestCaseFilter:FullyQualifiedName~Q1WriteTimeoutMustEndAtWriteAndFlush' '--Logger:trx;LogFileName=wsl-baseline.trx' "--ResultsDirectory:$base/campaign"