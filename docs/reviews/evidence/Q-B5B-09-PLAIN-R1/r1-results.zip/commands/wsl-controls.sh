set -u
base=/mnt/c/Users/Laszlos/source/repos/Solo/qb5b09-plain-r1
cd "$base/controls" || exit
export DOTNET_ROLL_FORWARD=Major
name=$1
dotnet vstest tests/BoltSharp.Tests/bin/Debug/net8.0/BoltSharp.Tests.dll \
  '--TestCaseFilter:FullyQualifiedName~SuccessfulWriteEndsWriteTimeoutBeforeObserver' \
  "--Logger:trx;LogFileName=wsl-$name.trx" "--ResultsDirectory:$base/campaign"
