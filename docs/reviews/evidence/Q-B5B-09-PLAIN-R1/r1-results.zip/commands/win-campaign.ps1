$log = (Get-Item ..\campaign).FullName
$core = 'tests/BoltSharp.Tests/BoltSharp.Tests.csproj'
$driver = 'tests/BoltSharp.DriverInteropTests/BoltSharp.DriverInteropTests.csproj'
dotnet --info > "$log\win-sdk.log"
dotnet restore BoltSharp.slnx --ignore-failed-sources *> "$log\win-restore.log"
if ($LASTEXITCODE) { exit $LASTEXITCODE }
dotnet restore $driver --ignore-failed-sources *> "$log\win-restore-driver.log"
if ($LASTEXITCODE) { exit $LASTEXITCODE }
dotnet build src/BoltSharp/BoltSharp.csproj --no-restore -nodeReuse:false *> "$log\win-build-production.log"
if ($LASTEXITCODE) { exit $LASTEXITCODE }
dotnet build BoltSharp.slnx --no-restore -nodeReuse:false *> "$log\win-build-solution.log"
if ($LASTEXITCODE) { exit $LASTEXITCODE }
dotnet build $driver --no-restore -nodeReuse:false *> "$log\win-build-driver.log"
if ($LASTEXITCODE) { exit $LASTEXITCODE }
$focus = 'FullyQualifiedName~PlaintextTerminalClose|FullyQualifiedName~TlsIntegrationTests|FullyQualifiedName~TcpListenerTests|FullyQualifiedName~MultiClient'
foreach ($i in 1..3) {
    dotnet test $core --no-build --no-restore --filter $focus --logger "trx;LogFileName=win-focused-$i.trx" --results-directory $log *> "$log\win-focused-$i.log"
}
dotnet test $core --no-build --no-restore --logger 'trx;LogFileName=win-core.trx' --results-directory $log *> "$log\win-core.log"
dotnet test $driver --no-build --no-restore --logger 'trx;LogFileName=win-driver.trx' --results-directory $log *> "$log\win-driver.log"
$scope = git diff --name-only 9dd2fe1 -- src tests
dotnet format BoltSharp.slnx --verify-no-changes --no-restore --include $scope *> "$log\win-format.log"
"format-exit=$LASTEXITCODE" | Set-Content "$log\win-format-status.log"
