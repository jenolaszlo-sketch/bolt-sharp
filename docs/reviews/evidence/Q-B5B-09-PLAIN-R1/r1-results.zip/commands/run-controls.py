import hashlib
from pathlib import Path
import subprocess

base = Path(__file__).resolve().parent
repo = base / "controls"
results = base / "campaign"
prefix = "src/BoltSharp/"
close = prefix + "Transport/BoltPlaintextTerminalClose.cs"
connection = prefix + "Transport/BoltTcpConnection.cs"
server = prefix + "Transport/BoltTcpServer.cs"
session = prefix + "Sessions/BoltConnectionSession.cs"
project = "tests/BoltSharp.Tests/BoltSharp.Tests.csproj"
source = base / "source"
candidate_files = [
    close, connection, server, "tests/BoltSharp.Tests/Transport/PlaintextTerminalCloseTests.cs",
]
controls = {
    "01": ("ExactFailureAndNoTrailingExecution", [
        (session, "            return authenticated ? refusal.MarkPlaintextCloseEligible() : refusal;",
         "            if (authenticated)\n                _state = BoltConnectionState.Ready;\n            return authenticated ? refusal.MarkPlaintextCloseEligible() : refusal;"),
        (connection, "                    (cancellation, pending) => WritePlaintextTerminalResponseAsync(\n                        plaintext, codec, result.Responses, cancellation, pending),",
         "                    async (cancellation, pending) =>\n                    {\n                        await WritePlaintextTerminalResponseAsync(plaintext, codec, result.Responses, cancellation, pending).ConfigureAwait(false);\n                        if (await reader.ReadMessageAsync(cancellation).ConfigureAwait(false) is { } queued)\n                            _ = session.ReceiveBytes(queued);\n                    },"),
    ]),
    "02": ("ListenerStopJoinsActualHandleAndReturnsPermit", [
        (connection, "        using var clientOwnership = client;", "        var clientOwnership = client;"),
        (close, "                Client.Dispose();", "                GC.KeepAlive(Client);"),
    ]),
    "03": ("ListenerStopJoinsActualHandleAndReturnsPermit", [
        (close, 'using var onListener = listener.UnsafeRegister(_ => owner.Interrupt("listener-shutdown"), null);',
         '// Fault injection: leave the listener unregistered.'),
    ]),
    "04": ("OneDeadlineCoversWriteAndDrain", [
        (close, "            ArmPhaseTimer(drain, DrainBudget, started, owner);",
         "            total.CancelAfter(TotalBudget);\n            ArmPhaseTimer(drain, DrainBudget, Stopwatch.GetTimestamp(), owner);"),
    ]),
    "05": ("ExactFailureAndNoTrailingExecution", [
        (close, "private const int DrainByteLimit = 8 * 1024;", "private const int DrainByteLimit = 12 * 1024;"),
    ]),
    "06": ("DrainAdmissionAndRecovery", [
        (close, "new SemaphoreSlim(Math.Min(1, maxConnections - 1), 1)",
         "new SemaphoreSlim(Math.Min(2, maxConnections - 1), 2)"),
    ]),
    "07": ("TlsRefusalNeverEntersPlaintextHelper", [
        (server, "options.Tls is null ? new BoltPlaintextTerminalClose(options.MaxConnections) : null",
         "new BoltPlaintextTerminalClose(options.Tls is null ? options.MaxConnections : 1)"),
        (connection, "options.Tls is null ? plaintextClose : null,", "plaintextClose,"),
        (connection, "var plaintext = (NetworkStream)stream;", "var plaintext = client.GetStream();"),
        (connection, "plaintext, codec, result.Responses, cancellation, pending),",
         "stream, codec, result.Responses, cancellation, pending),"),
        (connection, "        NetworkStream stream,\n        BoltMessageCodec codec,",
         "        Stream stream,\n        BoltMessageCodec codec,"),
    ]),
    "08": ("SuccessfulWriteEndsWriteTimeoutBeforeObserver", [
        (close, 'writeTimer.Token.UnsafeRegister(_ => InterruptWrite("write-deadline"), null)',
         'writeTimer.Token.UnsafeRegister(_ => owner.Interrupt("write-deadline"), null)'),
        (close, '                phase = "post-write";',
         '                Report("write-complete");\n                messageProcessed();\n                owner.Token.ThrowIfCancellationRequested();\n                phase = "post-write";'),
        (close, '            Report("write-complete");\n            messageProcessed();\n            if (Remaining(started)',
         '            if (Remaining(started)'),
    ]),
}


def run(args, name):
    with (results / f"{name}.log").open("wb") as out:
        return subprocess.run(args, cwd=repo, stdout=out, stderr=subprocess.STDOUT).returncode


def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo)


def test(name, names):
    scope = "|".join(f"FullyQualifiedName~PlaintextTerminalCloseTests.{name}" for name in names)
    args = ["dotnet", "test", project, "--no-restore", "-nodeReuse:false", "--filter", scope,
            "--logger", f"trx;LogFileName=win-{name}.trx", "--results-directory", str(results)]
    return run(args, f"win-{name}")


def test_wsl(name):
    script = "/mnt/c/Users/Laszlos/source/repos/Solo/qb5b09-plain-r1/wsl-controls.sh"
    return run(["wsl.exe", "-d", "Ubuntu", "--", "bash", script, name], f"wsl-{name}")


entry = "9dd2fe1b9b6f8ab2880e3fe50b8ef9ac2d43ae9c"
assert git("rev-parse", "HEAD").decode().strip() == entry
assert git("status", "--porcelain") == b""
for path in candidate_files:
    (repo / path).write_bytes((source / path).read_bytes())
candidate = git("diff", "--binary")
(results / "controls-candidate.patch").write_bytes(candidate)
assert run(["dotnet", "restore", project, "--ignore-failed-sources"], "nc-restore") == 0
control_filters = sorted({case[0] for case in controls.values()})
with (results / "nc-status.log").open("w", encoding="utf-8") as ledger:
    before = test("nc-00", control_filters)
    print("NC-00", before, file=ledger, flush=True)
    assert before == 0
    for number, (filter_name, edits) in controls.items():
        name = f"nc-{number}"
        originals = {path: (repo / path).read_bytes() for path, _, _ in edits}
        try:
            for path, expected, replacement in edits:
                target = repo / path
                data = target.read_bytes()
                eol = "\r\n" if b"\r\n" in data else "\n"
                expected = expected.replace("\n", eol).encode()
                replacement = replacement.replace("\n", eol).encode()
                assert data.count(expected) == 1, (name, path, expected)
                target.write_bytes(data.replace(expected, replacement))
            (results / f"{name}.patch").write_bytes(git("diff", "--binary"))
            print(name, "Windows", test(name, [filter_name]), file=ledger, flush=True)
            if number == "08":
                print(name, "WSL2", test_wsl(name), file=ledger, flush=True)
        finally:
            for path, data in originals.items():
                (repo / path).write_bytes(data)
            assert git("diff", "--binary") == candidate
            assert git("rev-parse", "HEAD").decode().strip() == entry
            print(name, "restored", hashlib.sha256(candidate).hexdigest(), file=ledger, flush=True)
    print("NC-00 restored Windows", test("nc-00-restored", control_filters), file=ledger, flush=True)
    print("NC-00 restored WSL2", test_wsl("nc-00-restored"), file=ledger, flush=True)
